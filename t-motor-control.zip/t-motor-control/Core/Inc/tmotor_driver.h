/*
 * tmotor_driver.h
 *
 *  Created on: Jan 28, 2024
 *      Author: xuzhekai
 */

#ifndef INC_TMOTOR_DRIVER_H_
#define INC_TMOTOR_DRIVER_H_

#include "main.h"
extern CAN_HandleTypeDef hcan1;

extern UART_HandleTypeDef huart2;

// Useful CAN Messages
typedef union{
	int16_t v_int;
	uint8_t u_int[2];
}Int16_uint8;

typedef struct
{
	float position; // radians
	float velocity; // rad / s
	float torque; // N*m
	int8_t temperature; // Not sure
	int8_t error;
	int16_t v_int;
	int16_t c_int;

} motor_state_t;

#define P_MIN -12.5f
#define P_MAX 12.5f
#define V_MIN -30.0f
#define V_MAX 30.0f
#define T_MIN -18.0f
#define T_MAX 18.0f

typedef enum {
	CAN_PACKET_SET_DUTY = 0,
	CAN_PACKET_SET_CURRENT,
	CAN_PACKET_SET_CURRENT_BRAKE,
	CAN_PACKET_SET_RPM,
	CAN_PACKET_SET_POS,
	CAN_PACKET_SET_ORIGIN_HERE,
	CAN_PACKET_SET_POS_SPD
}CAN_PACKET_ID;




/*
 * transmit via CAN
 */
void CAN_Transmit_eid(uint32_t id,
				const uint8_t* data,
					  uint8_t len,
					  uint32_t *TxMailbox);
void buffer_append_int32(uint8_t* buffer, int32_t number, int32_t* index);
void buffer_append_int16(uint8_t* buffer, int16_t number, int16_t * index);
void CAN_Set_Velocity(uint8_t controller_id, float rpm, uint32_t* TxMailbox);
void CAN_Set_Current(uint8_t controller_id, float current, uint32_t* TxMailbox);
void pack_cmd(uint8_t data[8],
			 float p_des,
			 float v_des,
			 float kp,
			 float kd,
			 float t_ff);





//Math equations
int float_to_uint(float x, float x_min, float x_max, unsigned int bits);
float uint_to_float(int x_int, float x_min, float x_max, int bits);
//void unpack_reply(uint8_t data[8]);
void motor_receive(motor_state_t* recv,
				   uint8_t rx_message[8]);


#endif /* INC_TMOTOR_DRIVER_H_ */
