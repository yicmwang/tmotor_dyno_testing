/*
 * ADS1115.c
 *
 *  Created on: Nov 2, 2023
 *      Author: xuzhekai
 */


#include "ADS1115.h"
#include "main.h"
#include "string.h"

int16_t get_ADC(int target){
	  unsigned char ADSwrite[6];
	  int16_t reading;
	//   float voltage[4];

	  ADSwrite[0] = 0x01;
	  if(target == TORQUE){
		  ADSwrite[1] = 0x8E;
		  ADSwrite[2] = 0x83;
	  }else if (target == CURRENT){
		  ADSwrite[1] = 0xBE;
		  ADSwrite[2] = 0x83;
	  }

	  HAL_I2C_Master_Transmit(&hi2c1, ADS1115_ADDR <<1, ADSwrite, 3 , 100);
	  memset(ADSwrite, 0, 6);
	  ADSwrite[0] = 0x00;
	  HAL_I2C_Master_Transmit(&hi2c1, ADS1115_ADDR <<1, ADSwrite, 1 , 100);
	  HAL_Delay(20);
	  memset(ADSwrite,0, 6);
	  HAL_I2C_Master_Receive(&hi2c1, ADS1115_ADDR << 1, ADSwrite, 2, 100);

	  reading = (ADSwrite[0] << 8 | ADSwrite[1]);

	  return reading;
}

void ADC_init(){
	//current FSR is set at the smallest, as the range will be 0.256V
	//which means LSB size is going to be 7.81uV
	unsigned char ADSwrite[6];
		ADSwrite[0] = 0x01;
		ADSwrite[1] = 0x8E;
		ADSwrite[2] = 0x83;
		if(HAL_I2C_Master_Transmit(&hi2c1, ADS1115_ADDR <<1, ADSwrite, 3 , 100) != HAL_OK){
			Error_Handler();
		}


}
